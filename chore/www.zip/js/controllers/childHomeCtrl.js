angular.module('chore').controller("childHomeCtrl", function($scope){
   $scope.test = "Message from  child Home controller"

})
