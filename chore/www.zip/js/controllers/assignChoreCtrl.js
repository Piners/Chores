angular.module('chore').controller("assignChoreCtrl", function($scope){
   $scope.test = "Message from assign chore controller"

})
