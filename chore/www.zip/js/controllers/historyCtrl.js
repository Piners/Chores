angular.module('chore').controller("historyCtrl", function($scope){
   $scope.test = "Message from History controller"

})
