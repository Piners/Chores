angular.module('chore').controller("userInfoCtrl", function($scope){
   $scope.test = "Message from info controller"

})
