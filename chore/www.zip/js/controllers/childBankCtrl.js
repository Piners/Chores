angular.module('chore').controller("childBankCtrl", function($scope){
   $scope.test = "Message from bank controller"

})
