angular.module('chore').controller("childLoginCtrl", function($scope){
   $scope.test = "Message from child Login controller"

})
