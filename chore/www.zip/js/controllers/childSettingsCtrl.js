angular.module('chore').controller("childSettingsCtrl", function($scope){
   $scope.test = "Message from child settings controller"

})
